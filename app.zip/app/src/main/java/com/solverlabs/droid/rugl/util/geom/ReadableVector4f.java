package com.solverlabs.droid.rugl.util.geom;


public interface ReadableVector4f extends ReadableVector3f {
    float getW();
}
