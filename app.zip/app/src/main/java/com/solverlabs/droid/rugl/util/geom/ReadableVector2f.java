package com.solverlabs.droid.rugl.util.geom;


public interface ReadableVector2f extends ReadableVector {
    float getX();

    float getY();
}
