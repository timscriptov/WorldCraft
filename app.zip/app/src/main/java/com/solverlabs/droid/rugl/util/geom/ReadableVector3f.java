package com.solverlabs.droid.rugl.util.geom;


public interface ReadableVector3f extends ReadableVector2f {
    float getZ();
}
