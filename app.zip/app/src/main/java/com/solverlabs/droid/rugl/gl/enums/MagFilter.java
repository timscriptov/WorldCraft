package com.solverlabs.droid.rugl.gl.enums;


public enum MagFilter {
    NEAREST(9728),
    LINEAR(9729);

    public final int value;

    MagFilter(int value) {
        this.value = value;
    }
}
