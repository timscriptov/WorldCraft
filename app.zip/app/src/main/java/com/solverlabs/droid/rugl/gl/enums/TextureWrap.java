package com.solverlabs.droid.rugl.gl.enums;


public enum TextureWrap {
    CLAMP_TO_EDGE(33071),
    REPEAT(10497);

    public final int value;

    TextureWrap(int value) {
        this.value = value;
    }
}
