package com.solverlabs.droid.rugl.geom;


public class StillWaterBlock {
    private final int x;
    private final int y;
    private final int z;

    public StillWaterBlock(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
