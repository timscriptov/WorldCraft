package com.solverlabs.droid.rugl.text;


public interface KerningSource {
    float computeKerning(char c, char c2);
}
