package com.solverlabs.droid.rugl;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.solverlabs.droid.rugl.res.ResourceLoader;
import com.solverlabs.worldcraft.BlockView;
import com.solverlabs.worldcraft.Enemy;
import com.solverlabs.worldcraft.GameMode;
import com.solverlabs.worldcraft.R;
import com.solverlabs.worldcraft.SoundManager;
import com.solverlabs.worldcraft.activity.InnAppActivity;
import com.solverlabs.worldcraft.factories.DescriptionFactory;
import com.solverlabs.worldcraft.multiplayer.Multiplayer;
import com.solverlabs.worldcraft.multiplayer.dialogs.PopupDialog;
import com.solverlabs.worldcraft.multiplayer.util.TextUtils;
import com.solverlabs.worldcraft.ui.ChatBox;
import com.solverlabs.worldcraft.util.KeyboardUtils;

import java.util.ArrayList;
import java.util.Set;
import java.util.Timer;
import java.util.TreeSet;


public abstract class GameActivity extends InnAppActivity implements Runnable {
    public static final boolean isFreeVersion = true;
    private static final String CHAT_COMMAND_HOME = "/home";
    protected Game game;
    protected ProgressDialog loadingDialog;
    protected AlertDialog readOnlyMapNotificationDialog;
    private RelativeLayout bannerLayout;
    private GameView gameView;
    private Button removeAdsButton;
    private Timer showBannerTimer;
    private Timer showPopupAdsTimer;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    public void start(Game game) {
        this.game = game;
        ResourceLoader.start(getResources());
        setContentView(R.layout.main_without_banner);
        this.gameView = (GameView) findViewById(R.id.gameViewWithoutBanner);
        this.gameView.init(game);
        Thread reportAbuseCatcher = new Thread(this);
        reportAbuseCatcher.start();
    }

    public void showToast(final String message, final boolean longShow) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast t = Toast.makeText(GameActivity.this.getApplicationContext(), message, longShow ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
                t.show();
            }
        });
    }

    public void showGameMenuDialog() {
        final Dialog menuDialog = new Dialog(this);
        menuDialog.setContentView(R.layout.menulayout);
        menuDialog.setTitle("Game menu");
        Button quitButton = (Button) menuDialog.findViewById(R.id.quitButton);
        Button backButton = (Button) menuDialog.findViewById(R.id.backButton);
        Button playersList = (Button) menuDialog.findViewById(R.id.playerListButton);
        if (GameMode.isMultiplayerMode()) {
            playersList.setVisibility(View.VISIBLE);
        } else {
            playersList.setVisibility(View.GONE);
        }
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (GameMode.isMultiplayerMode()) {
                    GameActivity.this.showLikeDialog();
                } else {
                    GameActivity.this.completeCurrentPhase(true);
                }
                SoundManager.stopAllSounds();
                menuDialog.dismiss();
            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menuDialog.dismiss();
            }
        });
        playersList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GameActivity.this.showPlayerList();
                menuDialog.dismiss();
            }
        });
        menuDialog.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showPlayerList() {
        final Dialog playerListDialog = new Dialog(this);
        playerListDialog.setContentView(R.layout.playerlist);
        ArrayList<String> list = new ArrayList<>();
        if (Multiplayer.instance != null) {
            playerListDialog.setTitle("Player list       Room name:  " + Multiplayer.instance.roomName);
            list.add(Multiplayer.instance.playerName + "   (you)");
            Set<Enemy> sortedEnemies = new TreeSet<>(Multiplayer.getEnemiesCopy());
            for (Enemy enemy : sortedEnemies) {
                list.add(enemy.name);
            }
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this, R.layout.custom_list_content, R.id.list_content, list);
        ListView playerList = (ListView) playerListDialog.findViewById(R.id.playerListView);
        playerList.setAdapter((ListAdapter) dataAdapter);
        Button cancelButton = (Button) playerListDialog.findViewById(R.id.cancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playerListDialog.dismiss();
            }
        });
        playerListDialog.show();
    }

    private void showLoadingDialog(final String message) {
        try {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!GameActivity.this.isFinishing()) {
                        GameActivity.this.loadingDialog = ProgressDialog.show(GameActivity.this, DescriptionFactory.emptyText, message, true);
                        GameActivity.this.loadingDialog.setCancelable(false);
                        GameActivity.this.loadingDialog.show();
                    }
                }
            });
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissLoadingDialog() {
        try {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (GameActivity.this.loadingDialog != null && !GameActivity.this.loadingDialog.isShowing()) {
                        GameActivity.this.loadingDialog.dismiss();
                    }
                }
            });
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r0v0, types: [com.solverlabs.droid.rugl.GameActivity$11] */
    public void saveWorld(final String worldName) {
        new Thread() {
            @Override
            public void run() {
                try {
                    GameActivity.this.gameView.game.getBlockView().saveWorld(worldName);
                } catch (Throwable th) {
                }
                try {
                    GameActivity.this.completeCurrentPhase(true);
                } catch (Throwable th2) {
                }
            }
        }.start();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.solverlabs.droid.rugl.GameActivity$12] */
    public void completeCurrentPhase(final boolean needSaveWorld) {
        new Thread() {
            @Override
            public void run() {
                try {
                    GameActivity.this.gameView.game.getBlockView().complete(needSaveWorld);
                } catch (Throwable th) {
                }
                try {
                    Multiplayer.instance.shutdown();
                    GameActivity.this.dismissLoadingDialog();
                } catch (Throwable th2) {
                }
            }
        }.start();
    }

    public void showSaveWorldDialogOnConnectionLost() {
        showSaveWorldDialog(R.string.connection_lost_would_you_like_to_save_world);
    }

    public void showSaveWorldDialog() {
        showSaveWorldDialog(R.string.would_you_like_to_save_world);
    }

    public void showReadOnlyRoomModificationDialog() {
        showSaveWorldDialog(R.string.modification_read_only_world_warning, 17039360, false);
    }

    public void showSaveWorldDialog(int stringId) {
        showSaveWorldDialog(stringId, R.string.dont_save, true);
    }

    public void showSaveWorldDialog(final int stringId, final int noButtonResourseId, final boolean completePhaseOnNoClick) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (GameActivity.this.readOnlyMapNotificationDialog == null || !GameActivity.this.readOnlyMapNotificationDialog.isShowing()) {
                    final EditText input = new EditText(GameActivity.this);
                    input.setHint(R.string.world_name);
                    input.setText(Multiplayer.instance.roomName);
                    KeyboardUtils.hideKeyboardOnEnter(GameActivity.this, input);
                    AlertDialog.Builder builder = new AlertDialog.Builder(GameActivity.this);
                    builder.setTitle(R.string.save_world).setMessage(stringId).setView(input).setCancelable(false).setPositiveButton(R.string.save_world, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            String worldName = String.valueOf(input.getText());
                            if (worldName != null && !DescriptionFactory.emptyText.equals(worldName) && !"null".equals(worldName)) {
                                GameActivity.this.saveWorld(worldName);
                                GameActivity.this.hideKeyBoard(input);
                                return;
                            }
                            Toast.makeText(GameActivity.this, R.string.wrong_world_name, Toast.LENGTH_LONG).show();
                        }
                    }).setNeutralButton(noButtonResourseId, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            if (completePhaseOnNoClick) {
                                GameActivity.this.completeCurrentPhase(false);
                            }
                        }
                    });
                    GameActivity.this.readOnlyMapNotificationDialog = builder.create();
                    GameActivity.this.readOnlyMapNotificationDialog.getWindow().setSoftInputMode(2);
                    GameActivity.this.readOnlyMapNotificationDialog.show();
                }
            }
        });
    }

    public void showLikeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.like_it).setMessage(R.string.did_you_like_this_world).setCancelable(false).setPositiveButton(R.string.like, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Multiplayer.instance.likeWorld();
                dialog.dismiss();
                GameActivity.this.showSaveWorldDialog();
            }
        }).setNegativeButton(R.string.dislike, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Multiplayer.instance.dislikeWorld();
                dialog.dismiss();
                GameActivity.this.showSaveWorldDialog();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r2v3, types: [com.solverlabs.droid.rugl.GameActivity$16] */
    public void sendChatMessage(final EditText msg) {
        BlockView phase;
        final String messageText = String.valueOf(msg.getText());
        if (CHAT_COMMAND_HOME.equals(messageText)) {
            if (this.game != null && this.game.getBlockView() != null && (phase = this.game.getBlockView()) != null && (phase instanceof BlockView)) {
                phase.resetPlayerLocation();
                return;
            }
            return;
        }
        new Thread() {
            @Override
            public void run() {
                if (Multiplayer.instance.gameClient != null && TextUtils.isEditTextMessageEmpty(msg)) {
                    Multiplayer.instance.gameClient.chat(messageText);
                }
            }
        }.start();
    }

    public void showChatDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText msg = new EditText(this);
        msg.setFilters(new InputFilter[]{new InputFilter.LengthFilter(ChatBox.getMaxChatMessageLength())});
        builder.setTitle(R.string.your_message).setView(msg).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                GameActivity.this.sendChatMessage(msg);
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        final AlertDialog alert = builder.create();
        msg.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (event == null || event.getKeyCode() != 66) {
                    return false;
                }
                GameActivity.this.sendChatMessage(msg);
                alert.dismiss();
                return true;
            }
        });
        alert.show();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onPause() {
        super.onPause();
        dismissLoadingDialog();
        if (this.gameView != null) {
            this.gameView.onPause();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onResume() {
        super.onResume();
        if (this.gameView != null) {
            this.gameView.onResume();
        }
        if (this.game != null) {
            this.game.resetTouches();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        BlockView p;
        if (event.getRepeatCount() == 0 && this.gameView != null && this.gameView.game != null && (p = this.gameView.game.getBlockView()) != null) {
            if (keyCode == 4 && (p instanceof BlockView)) {
                showGameMenuDialog();
            } else {
                p.onKeyDown(keyCode, event);
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        BlockView p;
        if (this.gameView != null && this.gameView.game != null && (p = this.gameView.game.getBlockView()) != null) {
            p.onKeyUp(keyCode, event);
            return true;
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideKeyBoard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void run() {
        while (GameMode.isMultiplayerMode()) {
            String message = Multiplayer.pollPopupMessage();
            if (message != null) {
                PopupDialog.showInUiThread(R.string.warning, message, this);
            }
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException e) {
            }
        }
    }
}
