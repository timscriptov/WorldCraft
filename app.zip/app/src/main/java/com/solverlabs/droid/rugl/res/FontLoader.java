package com.solverlabs.droid.rugl.res;

import android.util.Log;

import com.solverlabs.droid.rugl.Game;
import com.solverlabs.droid.rugl.text.Font;

import java.io.IOException;
import java.io.InputStream;


public abstract class FontLoader extends ResourceLoader.Loader<Font> {
    private final boolean mipmap;
    private final int resourceID;

    public FontLoader(int resourceID, boolean mipmap) {
        this.resourceID = resourceID;
        this.mipmap = mipmap;
    }

    public abstract void fontLoaded();

    /* JADX WARN: Type inference failed for: r2v2, types: [T, com.solverlabs.droid.rugl.text.Font] */
    @Override
    public void load() {
        InputStream is = ResourceLoader.resources.openRawResource(this.resourceID);
        try {
            this.resource = new Font(is);
        } catch (IOException e) {
            this.exception = e;
            Log.e(Game.RUGL_TAG, "Problem loading font " + this.resourceID, e);
        }
    }

    @Override
    public final void complete() {
        if (this.resource != null) {
            ((Font) this.resource).init(this.mipmap);
            fontLoaded();
        }
    }

    public String toString() {
        return "Font loader " + this.resourceID + " mipmap = " + this.mipmap;
    }
}
