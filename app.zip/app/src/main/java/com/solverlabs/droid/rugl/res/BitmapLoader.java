package com.solverlabs.droid.rugl.res;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.solverlabs.droid.rugl.texture.BitmapImage;
import com.solverlabs.worldcraft.factories.DescriptionFactory;


public abstract class BitmapLoader extends ResourceLoader.Loader<BitmapImage> {
    private static BitmapFactory.Options opts = new BitmapFactory.Options();

    static {
        opts.inDither = false;
        opts.inPurgeable = true;
        opts.inInputShareable = true;
        opts.inTempStorage = new byte[32768];
    }

    private final int id;

    public BitmapLoader(int id) {
        this.id = id;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [T, com.solverlabs.droid.rugl.texture.BitmapImage] */
    @Override
    public void load() {
        Bitmap b = BitmapFactory.decodeResource(ResourceLoader.resources, this.id, opts);
        this.resource = new BitmapImage(b);
    }

    public String toString() {
        return "Bitmap id = " + this.id + (this.resource != null ? " " + ((BitmapImage) this.resource).width + "x" + ((BitmapImage) this.resource).height : DescriptionFactory.emptyText);
    }
}
