package com.solverlabs.droid.rugl.util.geom;


public interface WritableVector3f extends WritableVector2f {
    void set(float f, float f2, float f3);

    void setZ(float f);
}
