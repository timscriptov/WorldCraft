package com.solverlabs.droid.rugl.res;

import android.content.res.Resources;

import java.util.LinkedList;


public class ResourceLoader {
    public static Resources resources;
    public static LinkedList<Loader<?>> complete = new LinkedList<>();
    protected static LoaderService postLoaderService = new LoaderService();
    private static LoaderService loaderService;

    static {
        loaderService = new LoaderService();
        loaderService = new LoaderService();
        loaderService.start();
        postLoaderService.start();
    }

    public static void start(Resources resources2) {
        resources = resources2;
    }

    public static void load(Loader<?> l) {
        loaderService.add(new LoaderRunnable(l));
    }

    public static void loadNow(Loader<?> l) {
        l.load();
        l.postLoad();
        l.complete();
    }

    public static void checkCompletion() {
        while (!complete.isEmpty()) {
            Loader<?> l = complete.remove(0);
            l.complete();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */

    public static class LoaderService implements Runnable {
        private static final long SLEEP_TIME = 10;
        LinkedList<Runnable> queue = new LinkedList<>();
        private boolean active;

        public void add(Runnable runnable) {
            synchronized (this.queue) {
                this.queue.offer(runnable);
            }
        }

        public Runnable poll() {
            Runnable runnable;
            synchronized (this.queue) {
                runnable = this.queue.poll();
            }
            return runnable;
        }

        @Override
        public void run() {
            while (this.active) {
                try {
                    Runnable runnable = poll();
                    if (runnable != null) {
                        runnable.run();
                    }
                    Thread.sleep(10L);
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }

        public void start() {
            this.active = true;
            Thread t = new Thread(this);
            t.setPriority(1);
            t.start();
        }

        public void stop() {
            this.active = false;
        }
    }


    public static abstract class Loader<T> {
        public boolean selfCompleting = true;
        protected Throwable exception;
        protected T resource;

        public abstract void complete();

        public abstract void load();

        public void postLoad() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */

    public static class LoaderRunnable implements Runnable {
        private final Loader<?> loader;
        private boolean loaded;

        private LoaderRunnable(Loader<?> loader) {
            this.loaded = false;
            this.loader = loader;
        }

        @Override
        public void run() {
            if (!this.loaded) {
                this.loader.load();
                this.loaded = true;
                ResourceLoader.postLoaderService.add(this);
                return;
            }
            this.loader.postLoad();
            if (this.loader.selfCompleting) {
                this.loader.complete();
            } else {
                ResourceLoader.complete.add(this.loader);
            }
        }
    }
}
