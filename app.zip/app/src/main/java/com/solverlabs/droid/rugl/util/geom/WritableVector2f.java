package com.solverlabs.droid.rugl.util.geom;


public interface WritableVector2f {
    void set(float f, float f2);

    void setX(float f);

    void setY(float f);
}
