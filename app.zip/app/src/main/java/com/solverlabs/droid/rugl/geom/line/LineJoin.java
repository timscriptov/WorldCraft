package com.solverlabs.droid.rugl.geom.line;

import com.solverlabs.droid.rugl.util.geom.Vector2f;

import java.util.List;


public interface LineJoin {
    void createVerts(Vector2f vector2f, Vector2f vector2f2, Vector2f vector2f3, Vector2f vector2f4, List<Vector2f> list, List<Short> list2);
}
