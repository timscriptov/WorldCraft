package com.solverlabs.worldcraft.ui;


public interface OptionItem {
    boolean hasImage();

    boolean isSection();
}
