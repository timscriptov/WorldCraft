package com.solverlabs.worldcraft.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.ViewGroup;
import android.widget.Button;


public class CustomView extends ViewGroup {
    private Button deleteSave;
    private Paint paint;
    private String worldName;

    public CustomView(Context context, String worldName) {
        super(context);
        this.paint = new Paint();
        this.worldName = worldName;
        this.deleteSave = new Button(context);
        this.deleteSave.setText("DELETE");
        addView(this.deleteSave);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        this.deleteSave.layout(0, 0, 0, 0);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawText(this.worldName, 0.0f, 0.0f, this.paint);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        canvas.drawText(this.worldName, 0.0f, 0.0f, this.paint);
    }

    @Override
    public void draw(Canvas canvas) {
        canvas.drawText(this.worldName, 0.0f, 0.0f, this.paint);
    }

    public String getWorldName() {
        return this.worldName;
    }

    @Override
    public String toString() {
        return this.worldName;
    }
}
