package com.solverlabs.worldcraft;

import android.app.Activity;
import android.app.Application;


public class MyApplication extends Application {
    public static final String APP_MARKET_URL = "market://details?id=com.solverlabs.worldcraft";
    public static final boolean isFree = true;
    private static final String FLURRY_ID = "XFHX9QJ3QQVWRNTMB74B";
    private static final String MARKET_AMAZON_NAME = "Amazon";
    private static final String MARKET_APP_WORLD_NAME = "AppWorld";
    private static final String MARKET_DEFAULT_NAME = "default";
    private static final String MARKET_GOOGLE_PLAY_NAME = "GooglePlay";
    public static String MORE_GAME_LINK = PlatformSettings.MORE_GAMES_LINK;
    private Activity currentActivity = null;

    public static boolean isGooglePlayApp() {
        return true;
    }

    public static boolean isAmazonApp() {
        return false;
    }

    public static boolean isAppWorldApp() {
        return false;
    }

    public static String getMarketName() {
        if (isGooglePlayApp()) {
            return MARKET_GOOGLE_PLAY_NAME;
        }
        if (isAmazonApp()) {
            return MARKET_AMAZON_NAME;
        }
        if (isAppWorldApp()) {
            return MARKET_APP_WORLD_NAME;
        }
        return MARKET_DEFAULT_NAME;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public Activity getCurrentActivity() {
        return this.currentActivity;
    }

    public void setCurrentActivity(Activity mCurrentActivity) {
        this.currentActivity = mCurrentActivity;
    }

    public boolean isCurrentActivity(Activity activity) {
        return (this.currentActivity == null || activity == null || !this.currentActivity.equals(activity)) ? false : true;
    }
}
