package com.solverlabs.worldcraft;


public class PlatformSettings {
    public static final String EMAIL_SUPPORT = "support@solverlabs.com";
    public static final String FLURRY_KEY = "XFHX9QJ3QQVWRNTMB74B";
    public static final boolean IS_ANDROID = true;
    public static final boolean IS_FREE = true;
    public static final boolean IS_KINDLE_FIRE = false;
    public static final boolean IS_PLAYBOOK = false;
    public static final String MARKET_LINK = "market://details?id=";
    public static final String MORE_GAMES_LINK = "market://search?q=SolverLabs";
}
