package com.solverlabs.worldcraft.activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.solverlabs.droid.rugl.util.WorldUtils;
import com.solverlabs.worldcraft.MyApplication;
import com.solverlabs.worldcraft.R;
import com.solverlabs.worldcraft.dialog.component.MolotButton;
import com.solverlabs.worldcraft.dialog.component.MolotTextView;
import com.solverlabs.worldcraft.dialog.tools.ui.SwipeView;
import com.solverlabs.worldcraft.ui.GUI;
import com.solverlabs.worldcraft.util.GameStarter;
import com.solverlabs.worldcraft.util.WorldGenerator;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

public class SingleplayerActivity extends CommonActivity {
    public static final String SHOULD_FINISH = "shouldFinish";
    private RotateAnimation rotateAnimation = null;
    private SwipeView swipeView = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.singleplayer);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        initSwipeView();
        MolotButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> SingleplayerActivity.this.finish());
        MolotButton createButton = findViewById(R.id.create_button);
        createButton.setOnClickListener(v -> {
            Intent intent = new Intent(SingleplayerActivity.this, NewGameSingleplayerActivity.class);
            SingleplayerActivity.this.startActivityForResult(intent, 1);
        });
    }

    @Override
    protected void onResume() {
        updateMapList();
        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1 && resultCode == -1 && data.getBooleanExtra(SHOULD_FINISH, false)) {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onItemClick(@NonNull WorldUtils.WorldInfo worldInfo) {
        GameStarter.startGame((MyApplication) getApplication(), this, worldInfo.file.getAbsolutePath(), false, 0, worldInfo.isCreative ? WorldGenerator.Mode.CREATIVE : WorldGenerator.Mode.SURVIVAL);
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDeleteClick(WorldUtils.WorldInfo worldInfo) {
        showDeleteSaveDialog(worldInfo);
    }

    private void initSwipeView() {
        this.swipeView = findViewById(R.id.level_swipe);
        this.swipeView.setPageWidth((getScreenWidth(GUI.HEIGHT) * 7) / 12);
    }

    private int getScreenWidth(int defaultValue) {
        try {
            int defaultValue2 = getWindowManager().getDefaultDisplay().getWidth();
            return defaultValue2;
        } catch (Throwable th) {
            return defaultValue;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r0v1, types: [com.solverlabs.worldcraft.activity.SingleplayerActivity$3] */
    public void updateMapList() {
        if (this.swipeView != null) {
            new Thread() {
                @Override
                public void run() {
                    SingleplayerActivity.this.startLoadingSpinnerAnimation();
                    if (WorldUtils.isStorageAvailable(SingleplayerActivity.this)) {
                        try {
                            SingleplayerActivity.this.updateLevelList(WorldUtils.getWorldListSortedByLastModification(SingleplayerActivity.this));
                        } catch (WorldUtils.StorageNotFoundException e) {
                            WorldUtils.showStorageNotFoundDialog(SingleplayerActivity.this);
                        }
                    } else {
                        WorldUtils.showStorageNotFoundDialog(SingleplayerActivity.this);
                    }
                    SingleplayerActivity.this.stopLoadingSpinnerAnimation();
                }
            }.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateLevelList(Collection<WorldUtils.WorldInfo> worldList) {
        final Collection<View> levelViewList = getLevelViewList(worldList);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SingleplayerActivity.this.swipeView.addAllViews(levelViewList);
            }
        });
    }

    private Collection<View> getLevelViewList(Collection<WorldUtils.WorldInfo> worldList) {
        Collection<View> levelViewList = new ArrayList<>();
        for (WorldUtils.WorldInfo worldInfo : worldList) {
            levelViewList.add(createView(worldInfo));
        }
        return levelViewList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startLoadingSpinnerAnimation() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ImageView loadingSpinner = SingleplayerActivity.this.getLoadingSpinner();
                loadingSpinner.setVisibility(View.VISIBLE);
                loadingSpinner.startAnimation(SingleplayerActivity.this.getRotateAnimation());
                SingleplayerActivity.this.swipeView.removeAllViews();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopLoadingSpinnerAnimation() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ImageView loadingSpinner = SingleplayerActivity.this.getLoadingSpinner();
                loadingSpinner.clearAnimation();
                loadingSpinner.setVisibility(View.GONE);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public ImageView getLoadingSpinner() {
        return findViewById(R.id.loading_spinner);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public RotateAnimation getRotateAnimation() {
        if (this.rotateAnimation == null) {
            this.rotateAnimation = new RotateAnimation(0.0f, 1800.0f, 1, 0.5f, 1, 0.5f);
            this.rotateAnimation.setDuration(7500L);
            this.rotateAnimation.setRepeatCount(-1);
            this.rotateAnimation.setInterpolator(new LinearInterpolator());
        }
        return this.rotateAnimation;
    }

    private LinearLayout createView(final WorldUtils.WorldInfo worldInfo) {
        LayoutInflater inflater = getLayoutInflater();
        LinearLayout view = (LinearLayout) inflater.inflate(R.layout.level_preview, null);
        view.setTag(worldInfo);
        ImageView icon = view.findViewById(R.id.game_mode_icon);
        MolotButton deleteButton = view.findViewById(R.id.delete_button);
        MolotTextView mapNameView = view.findViewById(R.id.map_name);
        MolotTextView mapModifiedAtView = view.findViewById(R.id.map_modified_at);
        MolotTextView mapModeView = view.findViewById(R.id.map_mode);
        mapNameView.setText(worldInfo.name);
        mapModifiedAtView.setText(DateFormat.format("MM/dd/yyyy hh:mmaa", worldInfo.modifiedAt));
        if (worldInfo.isCreative) {
            mapModeView.setText(R.string.creative);
            icon.setImageResource(R.drawable.creative_icon);
        } else {
            mapModeView.setText(R.string.survival);
            icon.setImageResource(R.drawable.survival_icon);
        }
        deleteButton.setOnClickListener(v -> SingleplayerActivity.this.onDeleteClick(worldInfo));
        LinearLayout levelView = view.findViewById(R.id.level_view);
        levelView.setOnClickListener(v -> SingleplayerActivity.this.onItemClick(worldInfo));
        return view;
    }

    private void showDeleteSaveDialog(final WorldUtils.WorldInfo worldInfo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.are_you_realy_want_to_delete_map, worldInfo.file.getName())).setPositiveButton(R.string.yes, (dialog, id) -> {
            SingleplayerActivity.this.deleteSave(worldInfo.file.getAbsolutePath());
            SingleplayerActivity.this.updateMapList();
        }).setNegativeButton(R.string.no, (dialog, id) -> dialog.dismiss());
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void deleteSave(String absolutePath) {
        File dir = new File(absolutePath);
        String[] list = dir.list();
        for (String str : list) {
            File file = new File(dir, str);
            if (file.isFile()) {
                file.delete();
            }
            if (file.isDirectory()) {
                deleteSave(file.getAbsolutePath());
            }
        }
        if (dir.isDirectory() && dir.list().length == 0) {
            dir.delete();
        }
    }
}
