package com.solverlabs.worldcraft.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import com.solverlabs.droid.rugl.Game;
import com.solverlabs.droid.rugl.GameActivity;
import com.solverlabs.droid.rugl.input.Touch;
import com.solverlabs.droid.rugl.res.ResourceLoader;
import com.solverlabs.droid.rugl.texture.TextureFactory;
import com.solverlabs.droid.rugl.util.geom.Vector2f;
import com.solverlabs.droid.rugl.util.geom.Vector3f;
import com.solverlabs.worldcraft.BlockView;
import com.solverlabs.worldcraft.GameMode;
import com.solverlabs.worldcraft.MyApplication;
import com.solverlabs.worldcraft.Persistence;
import com.solverlabs.worldcraft.Player;
import com.solverlabs.worldcraft.SoundManager;
import com.solverlabs.worldcraft.World;
import com.solverlabs.worldcraft.dialog.DeathMenuDialog;
import com.solverlabs.worldcraft.factories.BlockFactory;
import com.solverlabs.worldcraft.multiplayer.Multiplayer;
import com.solverlabs.worldcraft.multiplayer.dialogs.ReportAbuseDialog;
import com.solverlabs.worldcraft.nbt.RegionFileCache;
import com.solverlabs.worldcraft.nbt.Tag;
import com.solverlabs.worldcraft.nbt.TagLoader;
import com.solverlabs.worldcraft.ui.CustomProgressDialog;
import com.solverlabs.worldcraft.util.GameTime;
import com.solverlabs.worldcraft.util.WorldGenerator;

import org.apache.commons.compress.archivers.cpio.CpioConstants;

import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;


public class WorldCraftActivity extends GameActivity {
    protected MyApplication application;
    private BlockView bw;
    private DeathMenuDialog deathMenuDialog;
    private boolean isResumingGame = false;
    private ProgressDialog loadingProgressDialog;
    private ProgressDialog resumeDialog;
    private World world;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.application = (MyApplication) getApplicationContext();
        getWindow().addFlags(CpioConstants.C_IWUSR);
        String worldFileName = getIntent().getExtras().getString("world");
        boolean isNewGame = getIntent().getExtras().getBoolean("isNewGame");
        WorldGenerator.Mode gameMode = (WorldGenerator.Mode) getIntent().getExtras().get("gameMode");
        Touch.resetTouch();
        initSoundManager();
        Log.e(Game.RUGL_TAG, "loading " + worldFileName);
        File dir = new File(worldFileName);
        showProgressDialog();
        TagLoader tl = new AnonymousClass1(new File(dir, World.LEVEL_DAT_FILE_NAME), dir, isNewGame, gameMode);
        tl.selfCompleting = true;
        ResourceLoader.load(tl);
    }

    private void initSoundManager() {
        SoundManager.initSounds(this);
        SoundManager.loadSounds();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onPause() {
        clearReferences();
        if (this.world != null) {
            this.world.save();
        }
        this.isResumingGame = true;
        Log.d("ONPAUSE", "isResume  " + this.isResumingGame);
        if (this.loadingProgressDialog != null) {
            this.loadingProgressDialog.dismiss();
        }
        if (GameMode.isMultiplayerMode()) {
            Multiplayer.instance.shutdown();
            finish();
        }
        super.onPause();
    }

    private void clearReferences() {
        if (this.application.isCurrentActivity(this)) {
            this.application.setCurrentActivity(null);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onResume() {
        this.application.setCurrentActivity(this);
        if (this.isResumingGame) {
            this.isResumingGame = false;
            if (GameMode.isMultiplayerMode()) {
                super.finish();
                return;
            }
            showResumeDialog();
        }
        super.onResume();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    public void onDestroy() {
        TextureFactory.removeListener();
        if (this.bw != null) {
            this.bw.destroyWorld();
            this.bw = null;
            TextureFactory.deleteAllTextures();
        }
        RegionFileCache.clear();
        System.runFinalization();
        Runtime.getRuntime().gc();
        super.onDestroy();
    }

    @Override
    public void finish() {
        if (this.world != null && this.world.isNewGame) {
            deleteSave(this.world.dir.getAbsolutePath());
        }
        super.finish();
    }

    private void showResumeDialog() {
        if (this.resumeDialog == null) {
            this.resumeDialog = new ProgressDialog(this);
            this.resumeDialog.setTitle("Please wait");
            this.resumeDialog.setMessage("Resuming");
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                WorldCraftActivity.this.resumeDialog.show();
            }
        });
    }

    private void showProgressDialog() {
        if (this.loadingProgressDialog == null) {
            this.loadingProgressDialog = new CustomProgressDialog(this) {
                @Override
                public void onBackPressed() {
                    if (WorldCraftActivity.this.world != null) {
                        WorldCraftActivity.this.world.setCancel(true);
                    }
                    WorldCraftActivity.this.finish();
                }

                @Override
                public void buttonClick() {
                    if (WorldCraftActivity.this.world != null) {
                        WorldCraftActivity.this.world.setCancel(true);
                    }
                    WorldCraftActivity.this.finish();
                }
            };
        }
        this.loadingProgressDialog.show();
    }

    public void dismissProgresDialog() {
        this.loadingProgressDialog.dismiss();
    }

    public void dismissResumeDialog() {
        this.resumeDialog.dismiss();
    }

    public void dismissAllLoadingDialogs() {
        if (this.loadingProgressDialog != null && this.loadingProgressDialog.isShowing()) {
            this.loadingProgressDialog.dismiss();
        }
        if (this.resumeDialog != null && this.resumeDialog.isShowing()) {
            this.resumeDialog.dismiss();
        }
    }

    private void deleteSave(String absolutePath) {
        File dir = new File(absolutePath);
        String[] list = dir.list();
        if (list != null) {
            for (String str : list) {
                File file = new File(dir, str);
                if (file.isFile()) {
                    Log.d("del_file", "  " + file.delete());
                }
                if (file.isDirectory()) {
                    deleteSave(file.getAbsolutePath());
                }
            }
            if (dir.isDirectory() && dir.list().length == 0) {
                Log.d("del_dir", "  " + dir.delete());
            }
        }
    }

    /* renamed from: com.solverlabs.worldcraft.activity.WorldCraftActivity$1  reason: invalid class name */

    class AnonymousClass1 extends TagLoader {
        final /* synthetic */ File val$dir;
        final /* synthetic */ WorldGenerator.Mode val$gameMode;
        final /* synthetic */ boolean val$isNewGame;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(File x0, File file, boolean z, WorldGenerator.Mode mode) {
            super(x0);
            this.val$dir = file;
            this.val$isNewGame = z;
            this.val$gameMode = mode;
        }

        @Override
        public void complete() {
            WorldCraftActivity.this.runOnUiThread(new RunnableC00071());
        }

        /* renamed from: com.solverlabs.worldcraft.activity.WorldCraftActivity$1$1  reason: invalid class name and collision with other inner class name */

        class RunnableC00071 implements Runnable {
            RunnableC00071() {
            }

            @Override
            public void run() {
                int mapType;
                if (AnonymousClass1.this.resource == null) {
                    WorldCraftActivity.this.showToast("Could not load world level.dat\n" + AnonymousClass1.this.exception.getClass().getSimpleName() + ":" + AnonymousClass1.this.exception.getMessage(), true);
                    WorldCraftActivity.this.finish();
                    return;
                }
                try {
                    Tag time = ((Tag) AnonymousClass1.this.resource).findTagByName(WorldGenerator.LAST_PLAYED);
                    GameTime.initTime(((Long) time.getValue()).longValue());
                    Tag playerTag = ((Tag) AnonymousClass1.this.resource).findTagByName("Player");
                    Tag pos = playerTag.findTagByName("Pos");
                    Tag[] tl = (Tag[]) pos.getValue();
                    Vector3f p = new Vector3f();
                    p.x = ((Double) tl[0].getValue()).floatValue();
                    p.y = ((Double) tl[1].getValue()).floatValue();
                    p.z = ((Double) tl[2].getValue()).floatValue();
                    Tag rotaionTag = playerTag.findTagByName("Rotation");
                    Vector2f rotation = new Vector2f();
                    if (rotaionTag != null) {
                        Tag[] tl2 = (Tag[]) rotaionTag.getValue();
                        rotation.x = ((Float) tl2[0].getValue()).floatValue();
                        rotation.y = ((Float) tl2[1].getValue()).floatValue();
                        if (rotation.y > 1.5707964f || rotation.y < -1.5707964f) {
                            rotation.y = 0.0f;
                        }
                    }
                    Tag mapTypeTag = ((Tag) AnonymousClass1.this.resource).findTagByName(WorldGenerator.MAP_TYPE);
                    if (mapTypeTag != null) {
                        mapType = ((Integer) mapTypeTag.getValue()).intValue();
                    } else {
                        mapType = -1;
                    }
                    WorldCraftActivity.this.world = new World(AnonymousClass1.this.val$dir, p, (Tag) AnonymousClass1.this.resource) {
                        @Override
                        public boolean isLoadingDialogVisible() {
                            return WorldCraftActivity.this.loadingProgressDialog != null || WorldCraftActivity.this.loadingProgressDialog.isShowing();
                        }

                        @Override
                        public void incLoadingProgressStatus(int diff) {
                            WorldCraftActivity.this.loadingProgressDialog.incrementProgressBy(diff);
                        }

                        @Override
                        public void setLoadingProgressStatus(int progress, int max) {
                            WorldCraftActivity.this.loadingProgressDialog.setMax(max);
                            WorldCraftActivity.this.loadingProgressDialog.setProgress(progress);
                        }

                        @Override
                        public void showGameMenu() {
                            WorldCraftActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    WorldCraftActivity.this.showGameMenuDialog();
                                }
                            });
                        }

                        @Override
                        public void dismissLoadingDialog() {
                            if (WorldCraftActivity.this.loadingProgressDialog != null) {
                                WorldCraftActivity.this.loadingProgressDialog.dismiss();
                            }
                        }

                        @Override
                        public void dismissLoadingDialogAndWait() {
                            if (WorldCraftActivity.this.loadingProgressDialog != null && WorldCraftActivity.this.loadingProgressDialog.isShowing()) {
                                final CountDownLatch latch = new CountDownLatch(1);
                                WorldCraftActivity.this.loadingProgressDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                    @Override
                                    public void onDismiss(DialogInterface dialog) {
                                        latch.countDown();
                                    }
                                });
                                WorldCraftActivity.this.loadingProgressDialog.dismiss();
                                try {
                                    latch.await(2L, TimeUnit.SECONDS);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void showChat() {
                            WorldCraftActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    WorldCraftActivity.this.showChatDialog();
                                }
                            });
                        }

                        @Override
                        public void showReportAbuse() {
                            WorldCraftActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ReportAbuseDialog reportAbuseDialog = new ReportAbuseDialog(WorldCraftActivity.this);
                                    reportAbuseDialog.show();
                                }
                            });
                        }

                        @Override
                        public void showDeathMenu(final Player player) {
                            WorldCraftActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (WorldCraftActivity.this.deathMenuDialog == null || !WorldCraftActivity.this.deathMenuDialog.isVisible()) {
                                        WorldCraftActivity.this.deathMenuDialog = new DeathMenuDialog(WorldCraftActivity.this, player);
                                        WorldCraftActivity.this.deathMenuDialog.show();
                                    }
                                }
                            });
                        }
                    };
                    WorldCraftActivity.this.world.setNewGame(AnonymousClass1.this.val$isNewGame);
                    WorldCraftActivity.this.world.setMapType(mapType);
                    ((CustomProgressDialog) WorldCraftActivity.this.loadingProgressDialog).updateMax(World.getLoadingLimit(AnonymousClass1.this.val$isNewGame));
                    WorldCraftActivity.this.bw = new BlockView(WorldCraftActivity.this.world);
                    if (GameMode.isMultiplayerMode()) {
                        Multiplayer.instance.blockView = WorldCraftActivity.this.bw;
                    }
                    WorldCraftActivity.this.bw.setCamRotation(rotation);
                    WorldCraftActivity.this.bw.cam.invert = Persistence.getInstance().isInvertY();
                    GameMode.setGameMode((GameMode.isMultiplayerMode() || !WorldGenerator.Mode.SURVIVAL.equals(AnonymousClass1.this.val$gameMode)) ? 1 : 0);
                    if (GameMode.isSurvivalMode() && !GameMode.isMultiplayerMode()) {
                        WorldCraftActivity.this.world.initSunLight();
                    }
                    initFog();
                    Game game = new Game(WorldCraftActivity.this, null, WorldCraftActivity.this.bw);
                    WorldCraftActivity.this.start(game);
                } catch (Exception e) {
                    WorldCraftActivity.this.showToast("Problem parsing level.dat - Maybe a corrupt file?", true);
                    Log.e(Game.RUGL_TAG, "Level.dat corrupted?", e);
                    WorldCraftActivity.this.finish();
                }
            }

            private void initFog() {
                float fogDistance = Persistence.getInstance().getFogDistance();
                if (fogDistance < 0.0f) {
                    fogDistance = 0.0f;
                }
                BlockFactory.state.fog.start = fogDistance;
                BlockFactory.state.fog.end = 10.0f + fogDistance;
            }
        }
    }
}
