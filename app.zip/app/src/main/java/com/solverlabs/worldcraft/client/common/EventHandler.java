package com.solverlabs.worldcraft.client.common;


public interface EventHandler {
    void handleEvent(ClientGameEvent clientGameEvent);
}
