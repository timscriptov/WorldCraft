package com.solverlabs.worldcraft.material;


public enum Material {
    WOOD,
    STONE,
    GRASS,
    GRAVEL,
    COW,
    SHEEP,
    PIG,
    ZOMBIE,
    EXPLOSIVE,
    FOOD,
    WATER,
    LAVA,
    HUMAN,
    UNKNOWN
}
