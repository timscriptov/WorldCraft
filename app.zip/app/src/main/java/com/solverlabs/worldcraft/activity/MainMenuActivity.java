package com.solverlabs.worldcraft.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.solverlabs.droid.rugl.res.ResourceLoader;
import com.solverlabs.worldcraft.GameMode;
import com.solverlabs.worldcraft.MyApplication;
import com.solverlabs.worldcraft.Persistence;
import com.solverlabs.worldcraft.R;
import com.solverlabs.worldcraft.factories.DescriptionFactory;
import com.solverlabs.worldcraft.multiplayer.MultiplayerActivityHelper;
import com.solverlabs.worldcraft.srv.Consts;
import com.solverlabs.worldcraft.util.KeyboardUtils;

public class MainMenuActivity extends InnAppActivity {
    public static final int MAP_TYPE_FLAT = 1;
    public static final int MAP_TYPE_PREDEFINED = 2;
    public static final int MAP_TYPE_RANDOM = 0;
    private static final int COUNT_FOR_SHOW_LIKE_IT = 10;
    public static int displayHeight;
    public static int displayWidth;
    public static String version = DescriptionFactory.emptyText;
    int enterCount;
    private MultiplayerActivityHelper activityHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        displayWidth = displaymetrics.widthPixels;
        displayHeight = displaymetrics.heightPixels;
        setContentView(R.layout.main_menu_view);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setTitle("WorldCraft");
        Persistence.initPersistence(this);
        this.activityHelper = new MultiplayerActivityHelper(this);
        ResourceLoader.start(getResources());
        initButtons();
    }

    @Override
    protected void onStart() {
        if (this.enterCount == 10) {
            showLikeItDialog();
        }
        super.onStart();
    }

    private void initButtons() {
        Button singleButton = (Button) findViewById(R.id.singlePlyerButton);
        Button multiplayerButton = (Button) findViewById(R.id.multiplayerButton);
        Button optionButton = (Button) findViewById(R.id.optionButton);
        singleButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenuActivity.this, SingleplayerActivity.class);
            startActivity(intent);
        });
        multiplayerButton.setOnClickListener(v -> {
            if (Persistence.getInstance().isFirstTimeStarted()) {
                showChangeNameDialog();
            } else {
                activityHelper.startMultiplayer();
            }
        });
        optionButton.setOnClickListener(v -> optionClick());
    }

    public void showChangeNameDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText name = new EditText(this);
        name.setHint(Persistence.getInstance().getPlayerName());
        KeyboardUtils.hideKeyboardOnEnter(this, name);
        builder.setTitle("Please enter your name for multiplayer! You can change your name in option menu");
        builder.setView(name).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                String userName = name.getText().toString();
                Persistence.getInstance().setPlayerName(userName);
                Persistence.getInstance().setFirstTimeStarted(false);
                activityHelper.startMultiplayer();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void optionClick() {
        Persistence.getInstance().setFirstTimeStarted(false);
        Intent i = new Intent(this, OptionActivity.class);
        startActivity(i);
    }

    private void showLikeItDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Please, let other people know about this app by posting a good review!!!").setPositiveButton("Like It", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Uri uri = Uri.parse(MyApplication.APP_MARKET_URL);
                startActivity(new Intent("android.intent.action.VIEW", uri));
                Persistence.getInstance().setEnterCount(-1);
                dialog.dismiss();
            }
        }).setNeutralButton("Later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Persistence.getInstance().setEnterCount(0);
                dialog.dismiss();
            }
        }).setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Persistence.getInstance().setEnterCount(-1);
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    protected void onResume() {
        if (this.activityHelper != null) {
            this.activityHelper.onResume(this);
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        this.enterCount = Persistence.getInstance().getEnterCount();
        if (this.enterCount < 10 && this.enterCount >= 0) {
            this.enterCount++;
            Persistence.getInstance().setEnterCount(this.enterCount);
        }
        if (!GameMode.isMultiplayerMode() && this.activityHelper != null) {
            this.activityHelper.onPause();
        }
        super.onPause();
    }
}
