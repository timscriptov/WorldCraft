package com.solverlabs.worldcraft.srv.common;


public class GameConfig {
    public int getInt(String str, int i) {
        return 0;
    }

    public String getString(String str, int i) {
        return null;
    }
}
