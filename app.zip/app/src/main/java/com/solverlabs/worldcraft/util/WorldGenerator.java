package com.solverlabs.worldcraft.util;

import android.app.Activity;

import com.solverlabs.droid.rugl.util.WorldUtils;
import com.solverlabs.worldcraft.World;
import com.solverlabs.worldcraft.activity.MainMenuActivity;
import com.solverlabs.worldcraft.factories.DescriptionFactory;
import com.solverlabs.worldcraft.nbt.Tag;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


public class WorldGenerator {
    public static final String BUILD_VERSION = "BuildVersion";
    public static final String GAME_TYPE = "GameType";
    public static final String LAST_PLAYED = "LastPlayed";
    public static final String MAP_TYPE = "MapType";

    public static String generateRandomMap(Activity activity, String worldName, int mapType, Mode mode) {
        if (mode.equals(Mode.SURVIVAL)) {
            mapType = 0;
        }
        int i = 0;
        String path = DescriptionFactory.emptyText;
        File dir = new File(WorldUtils.WORLD_DIR, worldName);
        if (dir.exists()) {
            do {
                dir = new File(WorldUtils.WORLD_DIR, worldName + i);
                i++;
            } while (dir.exists());
            File dir2 = dir;
            try {
                dir2.mkdirs();
                WorldUtils.addWorld(dir2);
                File file = new File(dir2, World.LEVEL_DAT_FILE_NAME);
                file.createNewFile();
                path = file.getParent();
                OutputStream os = new FileOutputStream(file);
                try {
                    Tag levelTag = createLevelTag(mode, mapType);
                    levelTag.writeTo(os, true);
                    File dir3 = new File(dir2, World.REGION_DIR_NAME);
                    try {
                        dir3.mkdir();
                        new File(dir3, "r.0.0.mcr").createNewFile();
                    } catch (IOException e) {
                        return path;
                    }
                } catch (IOException e2) {
                }
            } catch (IOException e3) {
            }
            return path;
        }
        try {
            File dir22 = dir;
            dir22.mkdirs();
            WorldUtils.addWorld(dir22);
            File file2 = new File(dir22, World.LEVEL_DAT_FILE_NAME);
            file2.createNewFile();
            path = file2.getParent();
            OutputStream os2 = new FileOutputStream(file2);
            Tag levelTag2 = createLevelTag(mode, mapType);
            levelTag2.writeTo(os2, true);
            File dir32 = new File(dir22, World.REGION_DIR_NAME);
            dir32.mkdir();
            new File(dir32, "r.0.0.mcr").createNewFile();
            return path;
        } catch (IOException e2) {
        }
        return path;
    }

    private static Tag createLevelTag(Mode mode, int mapType) {
        Tag[] tags = new Tag[9];
        tags[0] = new Tag(Tag.Type.TAG_Long, LAST_PLAYED, (Object) 0L);
        tags[1] = new Tag(Tag.Type.TAG_Int, "SpawnX", (Object) 50);
        tags[2] = new Tag(Tag.Type.TAG_Int, "SpawnY", (Object) 80);
        tags[3] = new Tag(Tag.Type.TAG_Int, "SpawnZ", (Object) 50);
        tags[4] = createPlayerTag();
        tags[5] = new Tag(Tag.Type.TAG_Int, GAME_TYPE, Integer.valueOf(mode == Mode.CREATIVE ? 1 : 0));
        tags[6] = new Tag(Tag.Type.TAG_Int, MAP_TYPE, Integer.valueOf(mapType));
        tags[7] = new Tag(Tag.Type.TAG_String, BUILD_VERSION, MainMenuActivity.version + "_J");
        tags[8] = new Tag(Tag.Type.TAG_End, (String) null, (Tag[]) null);
        Tag dataTag = new Tag(Tag.Type.TAG_Compound, "Data", tags);
        Tag res = new Tag(Tag.Type.TAG_Compound, DescriptionFactory.emptyText, new Tag[]{dataTag, new Tag(Tag.Type.TAG_End, (String) null, (Tag[]) null)});
        return res;
    }

    private static Tag createPlayerTag() {
        Tag[] tags = {new Tag("Pos", Tag.Type.TAG_Double), new Tag("Rotation", Tag.Type.TAG_Float), new Tag(Tag.Type.TAG_Short, "Health", (Object) (short) 20), new Tag("Inventory", Tag.Type.TAG_Compound), new Tag(Tag.Type.TAG_End, (String) null, (Tag[]) null)};
        tags[0].addTag(new Tag(Tag.Type.TAG_Double, "x", Double.valueOf(50.0d)));
        tags[0].addTag(new Tag(Tag.Type.TAG_Double, "y", Double.valueOf(80.0d)));
        tags[0].addTag(new Tag(Tag.Type.TAG_Double, "z", Double.valueOf(50.0d)));
        tags[1].addTag(new Tag(Tag.Type.TAG_Float, "heading", Float.valueOf(0.0f)));
        tags[1].addTag(new Tag(Tag.Type.TAG_Float, "elevation", Float.valueOf(0.0f)));
        Tag playerTag = new Tag(Tag.Type.TAG_Compound, "Player", tags);
        return playerTag;
    }


    public enum Mode {
        SURVIVAL,
        CREATIVE
    }
}
