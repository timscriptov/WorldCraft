package com.solverlabs.worldcraft.srv.util;

import com.solverlabs.worldcraft.srv.log.WcLog;


public class SocketDebugUtil {
    public static final boolean SOCKET_WRITE_DEBUG = false;
    protected static WcLog log = WcLog.getLogger("SocketDebugUtil");

    public static void debug(Object obj) {
    }
}
