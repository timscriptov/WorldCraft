package com.solverlabs.worldcraft.dialog.tools.util;

import android.view.View;


public class OverScrollDisabler {
    public static void disableOverScroll(View view) {
        view.setOverScrollMode(2);
    }
}
