package com.solverlabs.worldcraft.client.common;

import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SocketChannel;


public class NIOUtils {
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0029, code lost:
        r12.close();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static boolean channelWrite(SocketChannel socketChannel, ByteBuffer byteBuffer) {
        boolean z = false;
        long j = 0;
        long remaining = byteBuffer.remaining();
        if (remaining > 512) {
            System.err.println("PACKET IS TOO BIG!!!");
        }
        try {
            long currentTimeMillis = System.currentTimeMillis();
            while (true) {
                if (j == remaining) {
                    z = true;
                    break;
                } else if (System.currentTimeMillis() - currentTimeMillis > 2000) {
                    break;
                } else {
                    j += socketChannel.write(byteBuffer);
                    try {
                        Thread.sleep(10L);
                    } catch (InterruptedException e) {
                    }
                }
            }
        } catch (ClosedChannelException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        byteBuffer.rewind();
        return z;
    }

    public static byte[] getByteArray(ByteBuffer byteBuffer) {
        int i = byteBuffer.getInt();
        if (i == 0) {
            return null;
        }
        byte[] bArr = new byte[i];
        byteBuffer.get(bArr);
        return bArr;
    }

    public static String getStr(ByteBuffer byteBuffer) {
        int i = byteBuffer.getShort();
        if (i <= 0) {
            return null;
        }
        byte[] bArr = new byte[i];
        byteBuffer.get(bArr);
        return new String(bArr);
    }

    public static void prepBuffer(ClientGameEvent clientGameEvent, ByteBuffer byteBuffer) {
        byteBuffer.clear();
        byteBuffer.putInt(0);
        int position = byteBuffer.position();
        byteBuffer.putInt(0);
        byteBuffer.putInt(position, clientGameEvent.write(byteBuffer));
        byteBuffer.flip();
    }

    public static void putByteArray(ByteBuffer byteBuffer, byte[] bArr) {
        if (bArr == null) {
            byteBuffer.putInt(0);
            return;
        }
        byteBuffer.putInt(bArr.length);
        byteBuffer.put(bArr);
    }

    public static void putStr(ByteBuffer byteBuffer, String str) {
        if (str == null) {
            byteBuffer.putShort((short) 0);
            return;
        }
        byteBuffer.putShort((short) str.length());
        byteBuffer.put(str.getBytes());
    }
}
