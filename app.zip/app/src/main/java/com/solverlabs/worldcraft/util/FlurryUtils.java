package com.solverlabs.worldcraft.util;

import com.solverlabs.worldcraft.GameMode;

public class FlurryUtils {
    private static final String EVENT_START_GAME = "start_game";
    private static final String GAME_MODE = "game_mode";
    private static final String MAP_TYPE = "map_type";
    private static final String MULTIPLAYER = "multiplayer";
    private static final String SINGLEPLAYER = "singleplayer";

    public static void logStartGame() {
        if (GameMode.isMultiplayerMode()) {
            onMultiplayerStart();
        } else {
            onSingleplayerStart();
        }
    }

    public static void onMultiplayerStart() {
        onGameStart(MULTIPLAYER);
    }

    public static void onSingleplayerStart() {
        onGameStart(SINGLEPLAYER);
    }

    private static void onGameStart(final String gameType) {
    }

    public static void logMapType(final String mapTypeName) {
    }
}
