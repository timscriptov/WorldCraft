package com.solverlabs.worldcraft.ui;

import com.solverlabs.droid.rugl.geom.TexturedShape;
import com.solverlabs.droid.rugl.gl.StackedRenderer;
import com.solverlabs.droid.rugl.gl.State;
import com.solverlabs.droid.rugl.util.geom.BoundingRectangle;
import com.solverlabs.worldcraft.Player;
import com.solverlabs.worldcraft.factories.ItemFactory;


public class HealthBar {
    private static final int EMPTY_HEART = 0;
    private static final int FULL_HEART = 2;
    private static final int HALF_HEART = 1;
    private static final int HEART_COUNT = 10;
    private static final float SCALE_VALUE = 25.0f;
    private static TexturedShape emptyHeartActiveShape;
    private static TexturedShape emptyHeartShape;
    private static TexturedShape fullHeartActiveShape;
    private static TexturedShape fullHeartShape;
    private static TexturedShape halfHeartActiveShape;
    private static TexturedShape halfHeartShape;
    private final BoundingRectangle bounds = new BoundingRectangle(160.0f, 65.0f, 320.0f, 80.0f);
    private final Player player;

    public HealthBar(Player player) {
        this.player = player;
    }

    public static void initShapes(State itemState) {
        fullHeartActiveShape = ItemFactory.Item.getShape(10, 14);
        halfHeartActiveShape = ItemFactory.Item.getShape(11, 14);
        emptyHeartActiveShape = ItemFactory.Item.getShape(12, 14);
        fullHeartShape = ItemFactory.Item.getShape(13, 14);
        halfHeartShape = ItemFactory.Item.getShape(14, 14);
        emptyHeartShape = ItemFactory.Item.getShape(15, 14);
        fullHeartActiveShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
        halfHeartActiveShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
        emptyHeartActiveShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
        fullHeartShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
        halfHeartShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
        emptyHeartShape.mo74scale(SCALE_VALUE, SCALE_VALUE, SCALE_VALUE);
    }

    public void advance(float delta) {
    }

    public void draw(StackedRenderer sr) {
        byte[] playerHearts = HeartTypesProcessor.getHeartTypes(this.player.getHealthPoints());
        float offset = (this.bounds.x.getSpan() - 10.0f) / 12.0f;
        float yPos = this.bounds.y.toValue(0.5f);
        float xPos = (this.bounds.x.getMin() + 5.0f) - (offset / 2.0f);
        for (byte b : playerHearts) {
            xPos += offset;
            sr.pushMatrix();
            sr.translate(xPos, yPos, 0.0f);
            getHeartTexture(b).render(sr);
            sr.popMatrix();
            sr.render();
        }
    }

    private TexturedShape getHeartTexture(byte heartType) {
        if (this.player.isHealthJustUpdated()) {
            TexturedShape heartTexture = getHeartTextureActive(heartType);
            return heartTexture;
        }
        TexturedShape heartTexture2 = getHeartTextureRest(heartType);
        return heartTexture2;
    }

    private TexturedShape getHeartTextureRest(byte heartType) {
        switch (heartType) {
            case 0:
                return emptyHeartShape;
            case 1:
                return halfHeartShape;
            case 2:
                return fullHeartShape;
            default:
                return emptyHeartShape;
        }
    }

    private TexturedShape getHeartTextureActive(byte heartType) {
        switch (heartType) {
            case 0:
                return emptyHeartActiveShape;
            case 1:
                return halfHeartActiveShape;
            case 2:
                return fullHeartActiveShape;
            default:
                return emptyHeartActiveShape;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */

    public static class HeartTypesProcessor {
        private static byte[] heartTypes;
        private static int prevHealthPoints = -1;

        private HeartTypesProcessor() {
        }

        public static byte[] getHeartTypes(int healthPoints) {
            if (prevHealthPoints == healthPoints) {
                return heartTypes;
            }
            heartTypes = new byte[10];
            int tempHealth = healthPoints;
            for (int i = 0; i < 10; i++) {
                if (tempHealth >= 2) {
                    heartTypes[i] = 2;
                    tempHealth -= 2;
                } else if (tempHealth == 1) {
                    heartTypes[i] = 1;
                    tempHealth--;
                } else {
                    heartTypes[i] = 0;
                }
            }
            prevHealthPoints = healthPoints;
            return heartTypes;
        }
    }
}
