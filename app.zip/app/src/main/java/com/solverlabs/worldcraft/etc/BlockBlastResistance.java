package com.solverlabs.worldcraft.etc;

import com.solverlabs.worldcraft.factories.BlockFactory;

import java.util.HashMap;
import java.util.Map;


public class BlockBlastResistance {
    private static final float DEFAULT_BLAST_RESISTANCE = 5.0f;
    private static Map<Byte, Float> speedTable = new HashMap();

    static {
        speedTable.put((byte) 7, Float.valueOf(1.8E7f));
        speedTable.put((byte) 49, Float.valueOf(6000.0f));
        speedTable.put((byte) 10, Float.valueOf(500.0f));
        speedTable.put((byte) 11, Float.valueOf(500.0f));
        speedTable.put((byte) 8, Float.valueOf(500.0f));
        speedTable.put((byte) 9, Float.valueOf(500.0f));
        speedTable.put((byte) 120, Float.valueOf(30.0f));
        speedTable.put((byte) 45, Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.NETHER_BRICK_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.STONE_BRICK_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.STONE_BRICK_MOSSY_ID), Float.valueOf(30.0f));
        speedTable.put((byte) 4, Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.DIAMOND_BLOCK_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.GOLD_BLOCK_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.IRON_BLOCK_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.JUKEBOX_ID), Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.DOUBLE_SLAB_ID), Float.valueOf(30.0f));
        speedTable.put((byte) 44, Float.valueOf(30.0f));
        speedTable.put((byte) 1, Float.valueOf(30.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.CLOSED_IRON_DOOR_ID), Float.valueOf(25.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.DISPENSER_ID), Float.valueOf(17.5f));
        speedTable.put((byte) 61, Float.valueOf(6000.0f));
        speedTable.put((byte) 14, Float.valueOf(15.0f));
        speedTable.put((byte) 15, Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.COAL_ORE_ID), Float.valueOf(15.0f));
        speedTable.put((byte) 21, Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.DIAMOND_ORE_ID), Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.CLAY_ORE_ID), Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.CLOSED_WOOD_DOOR_ID), Float.valueOf(15.0f));
        speedTable.put((byte) 22, Float.valueOf(15.0f));
        speedTable.put((byte) 5, Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.WOOD_PLANK_PINE_ID), Float.valueOf(15.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.WOOD_PLANK_JUNGLE_ID), Float.valueOf(15.0f));
        speedTable.put((byte) 54, Float.valueOf(12.5f));
        speedTable.put((byte) 58, Float.valueOf(12.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.WOOD_ID), Float.valueOf(10.0f));
        speedTable.put((byte) 47, Float.valueOf(7.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.MELON_ID), Float.valueOf((float) DEFAULT_BLAST_RESISTANCE));
        speedTable.put(Byte.valueOf((byte) BlockFactory.PUMPKIN_ID), Float.valueOf((float) DEFAULT_BLAST_RESISTANCE));
        speedTable.put((byte) 25, Float.valueOf(4.0f));
        speedTable.put((byte) 24, Float.valueOf(4.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.SANDSTONE2_ID), Float.valueOf(4.0f));
        speedTable.put((byte) 35, Float.valueOf(4.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.FARMLAND_ID), Float.valueOf(3.0f));
        speedTable.put((byte) 13, Float.valueOf(3.0f));
        speedTable.put((byte) 19, Float.valueOf(3.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.GRASS_ID), Float.valueOf(3.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.SNOWY_GRASS_ID), Float.valueOf(3.0f));
        speedTable.put((byte) 2, Float.valueOf(2.5f));
        speedTable.put((byte) 3, Float.valueOf(2.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.ICE_ID), Float.valueOf(2.5f));
        speedTable.put((byte) 12, Float.valueOf(2.5f));
        speedTable.put((byte) 88, Float.valueOf(2.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.CACTUS_ID), Float.valueOf(2.0f));
        speedTable.put((byte) 76, Float.valueOf(2.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.NETHERRACK_ID), Float.valueOf(2.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.GLASS_ID), Float.valueOf(1.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.GLOW_STONE_ID), Float.valueOf(1.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.BED_ID), Float.valueOf(1.0f));
        speedTable.put((byte) 18, Float.valueOf(1.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.SNOW_ID), Float.valueOf(0.5f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.FLOWER_ID), Float.valueOf(0.0f));
        speedTable.put((byte) 46, Float.valueOf(0.0f));
        speedTable.put(Byte.valueOf((byte) BlockFactory.TORCH_ID), Float.valueOf(0.0f));
    }

    public static float getBlastResistance(byte blockType) {
        Float value = speedTable.get(Byte.valueOf(blockType));
        return value == null ? DEFAULT_BLAST_RESISTANCE : value.floatValue();
    }
}
