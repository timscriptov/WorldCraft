package com.solverlabs.worldcraft.chunk;

import android.util.Log;

import androidx.annotation.NonNull;

import com.solverlabs.droid.rugl.Game;
import com.solverlabs.droid.rugl.res.ResourceLoader;
import com.solverlabs.worldcraft.GameMode;
import com.solverlabs.worldcraft.World;
import com.solverlabs.worldcraft.nbt.RegionFileCache;

import java.io.DataInputStream;


/**
 * This is packaged up like this so it can happen on the resource loading
 * thread, rather than the main render thread
 */
public abstract class ChunkLoader extends ResourceLoader.Loader<Chunk> {
    private final World mWorld;

    private final int mX;

    private final int mZ;

    /**
     * @param w
     * @param x
     * @param z
     */
    public ChunkLoader(World w, int x, int z) {
        mWorld = w;
        mX = x;
        mZ = z;
    }

    @Override
    public void load() {
        try {
            DataInputStream is = RegionFileCache.getChunkDataInputStream(mWorld.mDir, mX, mZ);
            if (resource != null) {
                if (is != null) {
                    resource = new Chunk(mWorld, is);
                    if (resource.chunkX != mX || resource.chunkZ != mZ) {
                        Log.e(Game.RUGL_TAG, "expected " + this + ", got " + resource);
                    }
                }
            } else {
                if (!GameMode.isMultiplayerMode() && mWorld.getMapType() != -1 && GameMode.isSurvivalMode()) {
                    resource = new Chunk(mWorld, mX, mZ);
                    if (mWorld.getMapType() == 0) {
                        mWorld.generateTerrain(resource, false);
                    }
                    if (mWorld.getMapType() == 1) {
                        mWorld.generateTerrain(resource, true);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(Game.RUGL_TAG, "Problem loading chunk (" + mX + "," + mZ + ")", e);

            exception = e;
            resource = null;
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "chunk " + mX + ", " + mZ;
    }
}